<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;

class BarangController extends Controller
{
    protected $table = 'barang';
    protected $pk = 'idbarang';

    public function index()
    {
        // Pagination using raw SQL + LengthAwarePaginator
        $page = request()->get('page', 1);
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        // Count total rows
        $totalRow = DB::select("SELECT COUNT(*) AS cnt FROM `{$this->table}`");
        $total = $totalRow[0]->cnt ?? 0;

        // Fetch page data
        $rows = DB::select(
            "SELECT * FROM `{$this->table}` ORDER BY `{$this->pk}` DESC LIMIT ? OFFSET ?",
            [$perPage, $offset]
        );

        // Build paginator
        $paginator = new LengthAwarePaginator($rows, $total, $perPage, $page, [
            'path' => request()->url(),
            'query' => request()->query()
        ]);

        // return view with 'rows' like before
        return view('crud.barang.index', compact('rows'));
    }

    public function create()
    {
        // GET satuan where status = 1 (replace DB::table(...)->where(...)->get())
        $satuan = DB::select("SELECT * FROM `satuan` WHERE `status` = ?", [1]);

        return view('crud.barang.create', compact('satuan'));
    }

    public function store(Request $r)
    {
        $r->validate([
            'nama' => 'required|string',
            'jenis' => 'required|string',
            'idsatuan' => 'required|integer',
            'harga' => 'nullable|integer',
            'status' => 'nullable|in:0,1'
        ]);

        // Get max id (replace DB::table(...)->max(...))
        $maxRow = DB::select("SELECT MAX(`{$this->pk}`) AS maxid FROM `{$this->table}`");
        $max = $maxRow[0]->maxid ?? null;
        $newId = ($max === null) ? 1 : ($max + 1);

        // Insert (replace DB::table(...)->insert([...]))
        DB::insert(
            "INSERT INTO `{$this->table}` (`{$this->pk}`, `jenis`, `nama`, `idsatuan`, `status`, `harga`)
             VALUES (?, ?, ?, ?, ?, ?)",
            [
                $newId,
                $r->jenis,
                $r->nama,
                $r->idsatuan,
                $r->status ?? 1,
                $r->harga ?? 0
            ]
        );

        return redirect()->route('barang.index')->with('success', 'Barang ditambahkan');
    }

    public function show($id)
    {
        return redirect()->route('barang.edit', $id);
    }

    public function edit($id)
    {
        // Select single item (replace first())
        $items = DB::select("SELECT * FROM `{$this->table}` WHERE `{$this->pk}` = ? LIMIT 1", [$id]);
        $item = count($items) ? $items[0] : null;

        if (!$item) {
            return redirect()->route('barang.index')->with('error', 'Data tidak ditemukan');
        }

        // Get satuan
        $satuan = DB::select("SELECT * FROM `satuan` WHERE `status` = ?", [1]);

        return view('crud.barang.edit', compact('item', 'satuan'));
    }

    public function update(Request $r, $id)
    {
        $r->validate([
            'nama' => 'required|string',
            'jenis' => 'required|string',
            'idsatuan' => 'required|integer',
            'harga' => 'nullable|integer',
            'status' => 'nullable|in:0,1'
        ]);

        // Update using raw SQL (replace DB::table(...)->where(...)->update([...]))
        DB::update(
            "UPDATE `{$this->table}`
             SET `jenis` = ?, `nama` = ?, `idsatuan` = ?, `status` = ?, `harga` = ?
             WHERE `{$this->pk}` = ?",
            [
                $r->jenis,
                $r->nama,
                $r->idsatuan,
                $r->status ?? 1,
                $r->harga ?? 0,
                $id
            ]
        );

        return redirect()->route('barang.index')->with('success', 'Barang diperbarui');
    }

    public function destroy($id)
    {
        // DELETE using raw SQL (replace DB::table(...)->where(...)->delete())
        DB::delete("DELETE FROM `{$this->table}` WHERE `{$this->pk}` = ?", [$id]);

        return redirect()->route('barang.index')->with('success', 'Barang dihapus');
    }
}
