<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // nama database dari config (Laragon/localhost biasanya ada)
        $db = config('database.connections.mysql.database');

        // cek apakah view/table 'view_barang_satuan' ada di schema saat ini
        $exists = DB::select(
            'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
            [$db, 'view_barang_satuan']
        );

        $barang = [];

        if (!empty($exists)) {
            // ambil sample 3 baris dari view (mengganti DB::table(...)->limit(3)->get())
            $barang = DB::select('SELECT * FROM `view_barang_satuan` LIMIT 3');
        }

        // kembalikan ke view dengan variabel 'barang' (sama seperti sebelumnya)
        return view('dashboard', compact('barang'));
    }
}
