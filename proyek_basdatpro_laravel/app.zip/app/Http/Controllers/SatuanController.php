<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SatuanController extends Controller
{
    protected $table = 'satuan';
    protected $pk = 'idsatuan';

    public function index()
    {
        $rows = DB::table($this->table)->paginate(15);
        return view('crud.satuan.index', compact('rows'));
    }

    public function create()
    {
        return view('crud.satuan.create');
    }

    public function store(Request $r)
    {
        $r->validate([
            'nama_satuan' => 'required|string',
            'status' => 'nullable|in:0,1'
        ]);

        $max = DB::table($this->table)->max($this->pk);
        $newId = ($max === null) ? 1 : ($max + 1);

        DB::table($this->table)->insert([
            $this->pk => $newId,
            'nama_satuan' => $r->nama_satuan,
            'status' => $r->status ?? 1
        ]);

        return redirect()->route('satuan.index')->with('success','Satuan ditambahkan');
    }

    public function edit($id)
    {
        $item = DB::table($this->table)->where($this->pk, $id)->first();
        if(!$item) return redirect()->route('satuan.index')->with('error','Data tidak ditemukan');
        return view('crud.satuan.edit', compact('item'));
    }

    public function update(Request $r, $id)
    {
        $r->validate([
            'nama_satuan' => 'required|string',
            'status' => 'nullable|in:0,1'
        ]);

        DB::table($this->table)->where($this->pk, $id)->update([
            'nama_satuan' => $r->nama_satuan,
            'status' => $r->status ?? 1
        ]);

        return redirect()->route('satuan.index')->with('success','Satuan diperbarui');
    }

    public function destroy($id)
    {
        DB::table($this->table)->where($this->pk, $id)->delete();
        return redirect()->route('satuan.index')->with('success','Satuan dihapus');
    }
}
