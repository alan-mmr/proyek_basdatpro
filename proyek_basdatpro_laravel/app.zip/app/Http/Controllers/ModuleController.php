<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;

class ModuleController extends Controller
{
    // This controller inspects DB metadata and shows generic module views.
    // Converted to use raw SQL instead of query builder.

    public function index(Request $request)
    {
        // List tables/views for current database with pagination
        $page = $request->get('page', 1);
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        // Get current database name
        $dbNameRow = DB::select('SELECT DATABASE() AS dbname');
        $dbName = $dbNameRow[0]->dbname ?? null;

        // Fetch tables/views from information_schema
        $rows = DB::select(
            'SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME LIMIT ? OFFSET ?',
            [$dbName, $perPage, $offset]
        );

        // total count for paginator
        $totalRow = DB::select('SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?', [$dbName]);
        $total = $totalRow[0]->cnt ?? 0;

        $paginator = new LengthAwarePaginator($rows, $total, $perPage, $page, [
            'path' => request()->url(),
            'query' => request()->query()
        ]);

        return view('module.index', ['rows' => $paginator, 'dbName' => $dbName]);
    }

    public function checkViewExists($view)
    {
        // Replaces previous DB::select that checked INFORMATION_SCHEMA for a view/table
        $db = config('database.connections.mysql.database');
        $r = DB::select(
            'SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
            [$db, $view]
        );
        return !empty($r);
    }

    public function show($view)
{
    if (!$this->checkViewExists($view)) {
        abort(404, 'View not found');
    }

    // Ambil 3 baris pertama dari view
    $rows = DB::select("SELECT * FROM `" . $view . "` LIMIT 3");

    // Ambil nama kolom
    $cols = DB::select("SHOW COLUMNS FROM `" . $view . "`");
    $cols = array_map(fn($c) => $c->Field, $cols);

    // (Opsional) Dapatkan tabel terkait, seperti versi lama
    $relatedTables = []; // isi kalau kamu mau panggil getTablesFromView($view)

    return view('modules.generic', compact('view', 'rows', 'cols', 'relatedTables'));
}
    public function showColumns($name)
    {
        // Show columns for a table/view (replacement for SHOW COLUMNS or DESCRIBE)
        // NOTE: ensure $name is a valid table name (call checkViewExists first)
        $cols = DB::select('SHOW COLUMNS FROM `' . $name . '`');
        return view('module.columns', ['cols' => $cols, 'name' => $name]);
    }

    public function showData(Request $request, $name)
    {
        // Generic: show data from arbitrary table/view using raw SQL
        // WARNING: whitelist table names to avoid SQL injection when interpolating table name
        $page = $request->get('page', 1);
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        // Whitelist check
        $allowed = DB::select('SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()');
        $allowedNames = array_map(function($r){ return $r->TABLE_NAME; }, $allowed);
        if (!in_array($name, $allowedNames)) {
            abort(404);
        }

        // Count and fetch rows (parameter binding for limit/offset)
        $totalRow = DB::select("SELECT COUNT(*) AS cnt FROM `{$name}`");
        $total = $totalRow[0]->cnt ?? 0;

        $rows = DB::select("SELECT * FROM `{$name}` LIMIT ? OFFSET ?", [$perPage, $offset]);

        $paginator = new LengthAwarePaginator($rows, $total, $perPage, $page, [
            'path' => request()->url(),
            'query' => request()->query()
        ]);

        return view('module.data', ['rows' => $paginator, 'name' => $name]);
    }

    // Additional helper actions can be converted similarly:
    // - run selected queries (use extreme caution)
    // - export table to CSV (use DB::select and stream the result)
}
