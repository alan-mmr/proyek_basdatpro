<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $r)
    {
        $r->validate(['username' => 'required', 'password' => 'required']);
        $u = DB::table('view_user_role')->where('username', $r->username)->first();

        // NOTE: dump uses plain-text password — replace with Hash::check in prod
        if (!$u || $r->password !== $u->password) {
            return back()->withErrors(['login' => 'Credentials not valid'])->withInput();
        }

        session([
            'user' => [
                'iduser'     => $u->iduser,
                'username'   => $u->username,
                'nama_role'  => $u->nama_role,
                'idrole'     => $u->idrole,
            ]
        ]);

        return redirect()->intended('/');
    }

    public function logout(Request $r)
    {
        $r->session()->forget('user');
        return redirect('/login')->with('success', 'Logged out');
    }
}
